from modules.rohub import rohub, settings, utils
import json
import requests

if __name__ == '__main__':
    pass
    rohub.login(username="rpalma", password="gato_domestico")
    #rohub.login(username="bjaniak", password="perro_domestico")
    print(rohub.version())
    # x = rohub.ros_show_publications(identifier=ros_id)
    # print(x)
    ros = rohub.ros_create(title="moj_tytul1111", research_areas=["Biology"])
    ros_id = ros.identifier
    # x = ros.snapshot(create_doi=True, publication_services=["Zenodo"])
    # print(x)
    # print(ros.show_metadata())
    # ros.show_full_metadata()
    # ros.load_full_metadata()
    # print(ros.show_full_metadata())
    # print(ros.show_valid_creation_modes())
    # ros_id = "8a73c6f6-c73b-4407-827b-b2cabfed5d3a"
    # rohub.ros_load(identifier=ros_id)
    # x = rohub.ros_fork(identifier=ros_id)
    # print(x)
    # pub_id = "acf37b96-641e-410a-b04a-f9defedb41a9"
    # x = rohub.ros_show_publications(publication_id=pub_id)
    # print(x)
    # print(x)
    # print(settings.ACCESS_TOKEN)
    # print(settings.TOKEN_TYPE)
    # ros = rohub.ros_create(title="test888899000x", research_areas=["Biology", "Astronomy", "War"])
    # print(ros.identifier)
    # ros.get_full_metadata()
    # print(ros.golden)
    # print(ros.created_by)
    # ros.identifier = "something_else"
    # print(ros.research_areas)
    # ros.research_areas = ["Bullshit", "Physics", "Biology"]
    # print(ros.research_areas)
    # ros = rohub.ros_load(identifier="fd7635dd-409e-4ebe-b682-482837d6a674")
    # print(ros.identifier)
    # print(ros.research_areas)
    # print(ros.identifier)
    # print(ros.title)
    # print(ros.research_areas)
    # print(ros.owner)
    # print(ros.access_mode)
    # print(ros.status)

    # x = rohub.ros_upload(path_to_zip="testuje.zip")
    # print(x)
    #identifier = "edf8b325-8a45-4600-953e-cf467f53f652"
    # job_url = settings.API_URL + f"jobs/{job_id}/"
    # x = utils.get_request(url=job_url, use_token=True)
    # print(x.json())


    # geojson = {
    #     "@context": {
    #         "geojson": "https://purl.org/geojson/vocab#"
    #     },
    #     "type": "Feature",
    #     "geometry": {
    #         "type": "Point",
    #         "coordinates": [38.0, 38.0]
    #     }
    # }
    # url = settings.API_URL + f"ros/{ros_id}/annotations/"
    #
    # test_json = json.dumps(geojson)
    # print(test_json)
    # data = {"ro": ros_id,
    #         "body_specification_json": test_json}
    # headers = {'Authorization': f"{settings.TOKEN_TYPE.capitalize()} {settings.ACCESS_TOKEN}"}
    # r = requests.post(url=url, headers=headers, data=data, timeout=settings.TIMEOUT)
    # r.raise_for_status()
    # print(r.json())



    # x = rohub.ros_add_annotations(identifier=ros_id, body_specification_json=geojson)
    # print(x)
    # x = rohub.ros_archive(identifier=identifier)
    # print(x)
    # x = rohub.ros_delete(identifier=identifier)
    # print(x)
    #print(ros.identifier)
    #ros_id = "fea03a90-5f58-4584-b7e3-14eb231fa5f3"
    #annotation_id = "8c76c10a-fad1-4444-8ef2-3baea15410e4"
    #x = rohub.ros_add_annotations(identifier=ros_id)
    #x = rohub.ros_delete_annotation(ros_identifier=ros_id, annotation_identifier=annotation_id)
    #print(x)
    #x = rohub.ros_folder_delete(ros_identifier="edf8b325-8a45-4600-953e-cf467f53f652")
    # data = open("data.geojson")
    # data = data.read()
    # print(data)
    # x = rohub.ros_add_geolocation(identifier=ros_id, body_specification_json="data.geojson")
    # print(x)
    # ext_res = "https://box.psnc.pl/f/ccb92d741e/?raw=1"
    # x = rohub.ros_add_external_resource(identifier=ros_id, res_type="Document", input_url=ext_res)
    # print(x)
    #data = [{"property": "http://purl.org/dc/terms/license", "value": "https://creativecommons.org/licenses/by-nc-sa/6.0/igo/"}]
    # x = rohub.ros_add_folders(identifier=ros_id, name="testuje_dalej")
    # print(x)
    # folder_id = "c7b9f7a1-0272-4f01-994b-b868b1b836eb"
    # x = rohub.ros_delete_folder(folder_identifier=folder_id)
    # print(x)
    # x = rohub.ros_add_internal_resource(identifier=ros_id, file_path="main.py", res_type="Script")
    # print(x)
    # x = rohub.ros_add_annotations(identifier=ros_id)
    # print(x)
    # anno_id = "97293dfd-88a3-435c-ac42-61030398e775"
    # x = rohub.ros_delete_annotation(ros_identifier=ros_id, annotation_identifier=anno_id)
    # print(x)
    # x = rohub.ros_update(identifier=ros_id, title="new_title", research_areas=["Astronomy"])
    # print(x)