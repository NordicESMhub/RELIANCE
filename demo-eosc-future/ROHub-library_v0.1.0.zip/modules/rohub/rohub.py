import requests
import os
import zipfile
import json

from modules.rohub import settings, utils
from modules.rohub.ResearchObject import ResearchObject
from _version import __version__


###############################################################################
#              Main Methods.                                                  #
###############################################################################

def login(username, password):
    """
    Function that handles access token generation and results in saving token information.
    :param username: str -> username.
    :param password: str -> password.
    """
    url = settings.KEYCLOAK_URL
    settings.USERNAME = username
    settings.PASSWORD = password
    data = {'client_id': settings.KEYCLOAK_CLIENT_ID,
            'client_secret': settings.KEYCLOAK_CLIENT_SECRET,
            'username': settings.USERNAME,
            'password': settings.PASSWORD,
            'grant_type': settings.GRANT_TYPE}
    try:
        r = requests.post(url, data=data, timeout=settings.TIMEOUT)
        r.raise_for_status()
        r_json = r.json()
        settings.ACCESS_TOKEN = r_json.get('access_token')
        settings.ACCESS_TOKEN_VALID_TO = utils.valid_to(exp_time=r_json.get('expires_in'))
        settings.REFRESH_TOKEN = r_json.get('refresh_token')
        settings.REFRESH_TOKEN_VALID_TO = utils.valid_to(exp_time=r_json.get('refresh_expires_in'))
        settings.TOKEN_TYPE = r_json.get('token_type')
        settings.SESSION_STATE = r_json.get('session_state')
        print(f"Logged successfully as {username}.")
    except requests.exceptions.HTTPError as e:
        print("Http error occurred.")
        print(e.response.text)
    except requests.exceptions.ConnectionError as e:
        try:
            print("Connection error occurred. Trying again...")
            r = requests.post(url, data=data, timeout=settings.TIMEOUT)
        except requests.exceptions.ConnectionError as e:
            print("Connection error occurred for a second time. Aborting...")
            raise SystemExit(e.response.text)
    except requests.exceptions.Timeout as e:
        print("Timeout. Could not connect to the server.")
        raise SystemExit(e.response.text)
    except requests.exceptions.RequestException as e:
        raise SystemExit(e)


def whoami():
    """
    Function that returns information about the user that is currently logged in.
    :return: str -> username.
    """
    if settings.USERNAME:
        return settings.USERNAME
    else:
        return "Currently not logged in!"


def version():
    """
    Displays the current package version.
    :return str -> information regarding package version.
    """
    return f"You are currently using package {__version__}."


def set_retries(number_of_retries):
    """
    Function for setting up number of retries.
    :param number_of_retries: int -> number of retries
    """
    if not isinstance(number_of_retries, int):
        print(f"number_of_retries has to be an integer, not {type(number_of_retries)}!")
    else:
        settings.RETRIES = number_of_retries
        print(f"number of retries is now changed to {settings.RETRIES}.")


def set_sleep_time(sleep_time):
    """
    Function for setting up sleep time.
    :param sleep_time: int -> sleep time in seconds.
    """
    if not isinstance(sleep_time, int):
        print(f"sleep_time has to be an integer, not {type(sleep_time)}!")
    else:
        settings.SLEEP_TIME = sleep_time
        print(f"sleep_time is now changed to {settings.SLEEP_TIME}.")


def owned():
    """
    Function that is getting a list of Research Objects owned by the current user.
    :return JSON -> response containing list of Research Objects that belongs to a
    current user.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + "ros/owned/"
        r = utils.get_request(url=url, use_token=True)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def is_job_success(job_id):
    """
    Helper function for checking if job succeeded.
    :param job_id: str -> job's id.
    :return: JSON -> response containing job response object.
    """
    job_url = settings.API_URL + f"jobs/{job_id}/"
    job_r = utils.get_request(url=job_url, use_token=True)
    job_content = job_r.json()
    job_status = job_content['status']
    if job_status == "SUCCESS":
        return job_content
    else:
        job_success = utils.check_for_status(job_url=job_url)
        if job_success:
            # updating response after success.
            job_r = utils.get_request(url=job_url, use_token=True)
            job_content = job_r.json()
            return job_content
        else:
            msg = "Couldn't validate if uploading ended up with a success!"
            raise SystemExit(msg)

###############################################################################
#              ROS main methods.                                              #
###############################################################################


def search_ros_by_id(identifier):
    """
    Function that makes a query for Research Object based on given id.
    :param identifier: str -> Research Object's id.
    :return: JSON -> response containing Research Object for requested id.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/"
        r = utils.get_request(url=url, use_token=True)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_create(title, research_areas, description=None, access_mode=None,
               ros_type=None, template=None, owner=None, editors=None,
               readers=None, creation_mode=None):
    """
    Function that creates new Research Object.
    :param title: str -> title for the Research Object.
    :param research_areas: list -> list of research areas connected to the ResearchObject.
    :param description: str -> ResearchObject's description.
    :param access_mode: str -> ResearchObject's access mode.
    :param ros_type: str -> ResearchObject's type.
    :param template: str -> ResearchObject's template.
    :param owner: str -> ResearchObject's owner.
    :param editors: list -> ResearchObject's list of editors.
    :param readers: list -> ResearchObject's list of readers.
    :param creation_mode: str -> ResearchObject's creation mode.
    :return: ResearchObject class instance.
    """
    return ResearchObject.ResearchObject(title=title, research_areas=research_areas,
                                         description=description, access_mode=access_mode,
                                         ros_type=ros_type, template=template, owner=owner,
                                         editors=editors, readers=readers, creation_mode=creation_mode,
                                         post_request=True)


def ros_load(identifier):
    """
    Function that loads existing Research Object into Python class.
    :param identifier: str -> ResearchObject's identifier.
    :return: ResearchObject class instance.
    """
    return ResearchObject.ResearchObject(identifier=identifier, post_request=False)


def ros_content(identifier):
    """
    Function that retrieves content of the Research Object based on the id.
    :param identifier: str -> Research Object's id.
    :return: JSON -> response with content of the Research Object.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/content/"
        r = utils.get_request(url=url, use_token=True)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_full_metadata(identifier):
    """
    Function that retrieves full metadata of the Research Object based on id.
    :param identifier: str -> Research Object's id.
    :return: JSON -> response with full metadata of the Research Object.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/full/"
        r = utils.get_request(url=url, use_token=True)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_fork(identifier, title=None, description=None, create_doi=None, publication_services=None):
    """
    Function that creates a Research Object's fork.
    :param identifier: str -> Research Object's id.
    :param title: str ->  title for the Research Object.
    :param description: str -> description.
    :param create_doi: boolean -> doi is created if True, False otherwise.
    :param publication_services: list -> name of the service.
    :return: str -> id for forked Research Object.
    """
    if create_doi:
        if not isinstance(create_doi, bool):
            msg = f"create_doi parameter has to be a boolean type, not a {type(create_doi)}"
            raise SystemExit(msg)
    r = utils.get_request(url=settings.API_URL + "enums/")
    if r:
        available_enums = r.json()
        if publication_services:
            try:
                available_services = available_enums["publication_service"]
                publication_services = [s.upper() for s in publication_services if s.upper() in available_services]
                if len(publication_services) == 0:
                    publication_services = None
            except KeyError as e:
                print(f"Couldn't validate publication_services value! Omitting this parameter.")
                print(e)
                publication_services = None
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/evolution/"
        data = {"status": "FORK",
                "title": title,
                "description": description,
                "create_doi": create_doi,
                "publication_services": publication_services}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        job_id = content["identifier"]
        if job_id:
            fork_response = is_job_success(job_id=job_id)
            forked_results = fork_response.get("results")
            if forked_results:
                forked_ros_id = forked_results.split("/")[-2]
                return forked_ros_id
        else:
            msg = "Incorrect job response, couldn't validate if file was uploaded or not."
            raise SystemExit(msg)


def ros_snapshot(identifier, title=None, description=None, create_doi=None, publication_services=None):
    """
    Function that creates a Research Object's snapshot.
    :param identifier: str -> Research Object's id.
    :param title: str ->  title for the Research Object.
    :param description: str -> description.
    :param create_doi: boolean -> doi is created if True, False otherwise.
    :param publication_services: list -> name of the service.
    :return: str -> id of snapshot.
    """
    if create_doi:
        if not isinstance(create_doi, bool):
            msg = f"create_doi parameter has to be a boolean type, not a {type(create_doi)}"
            raise SystemExit(msg)
    r = utils.get_request(url=settings.API_URL + "enums/")
    if r:
        available_enums = r.json()
        if publication_services:
            try:
                available_services = available_enums["publication_service"]
                publication_services = [s.upper() for s in publication_services if s.upper() in available_services]
                if len(publication_services) == 0:
                    publication_services = None
            except KeyError as e:
                print(f"Couldn't validate publication_services value! Omitting this parameter.")
                print(e)
                publication_services = None
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/evolution/"
        data = {"status": "SNAPSHOT",
                "title": title,
                "description": description,
                "create_doi": create_doi,
                "publication_services": publication_services}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        job_id = content["identifier"]
        if job_id:
            snapshot_response = is_job_success(job_id=job_id)
            snapshot_results = snapshot_response.get("results")
            if snapshot_results:
                snapshot_ros_id = snapshot_results.split("/")[-2]
                return snapshot_ros_id
        else:
            msg = "Incorrect job response, couldn't validate if file was uploaded or not."
            raise SystemExit(msg)


def ros_archive(identifier, title=None, description=None, create_doi=None, publication_services=None):
    """
    Function that creates a Research Object's archive.
    :param identifier: str -> Research Object's id.
    :param title: str ->  title for the Research Object.
    :param description: str -> description.
    :param create_doi: boolean -> doi is created if True, False otherwise.
    :param publication_services: list -> name of the service.
    :return: id of archived Research Object
    """
    if create_doi:
        if not isinstance(create_doi, bool):
            msg = f"create_doi parameter has to be a boolean type, not a {type(create_doi)}"
            raise SystemExit(msg)
    r = utils.get_request(url=settings.API_URL + "enums/")
    if r:
        available_enums = r.json()
        if publication_services:
            try:
                available_services = available_enums["publication_service"]
                publication_services = [s.upper() for s in publication_services if s.upper() in available_services]
                if len(publication_services) == 0:
                    publication_services = None
            except KeyError as e:
                print(f"Couldn't validate publication_services value! Omitting this parameter.")
                print(e)
                publication_services = None
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/evolution/"
        data = {"status": "ARCHIVE",
                "title": title,
                "description": description,
                "create_doi": create_doi,
                "publication_services": publication_services}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        job_id = content["identifier"]
        if job_id:
            archive_response = is_job_success(job_id=job_id)
            archive_results = archive_response.get("results")
            if archive_results:
                archive_ros_id = archive_results.split("/")[-2]
                return archive_ros_id
        else:
            msg = "Incorrect job response, couldn't validate if file was uploaded or not."
            raise SystemExit(msg)


def ros_show_publications(identifier):
    """
    Function that shows publication details for a certain publication id.
    :param identifier: str -> publication's id.
    :return: dict -> useful information from response.
    """
    url = settings.API_URL + f"ros/{identifier}/publications/"
    r = utils.get_request(url=url, use_token=False)
    content = r.json()
    results = content.get("results")
    publications = []
    for result in results:
        publications.append({"doi": result.get("doi"),
                             "storage": result.get("storage"),
                             "url": result.get("url")})
    return publications


###############################################################################
#              ROS add methods.                                               #
###############################################################################


def ros_add_geolocation(identifier, body_specification_json=None):
    """
    Function that adds geolocation to the existing Research Object.
    :param identifier: str -> Research Object's id.
    :param body_specification_json: path to JSON file or Python serializable object that
    will be converted into JSON.
    :return: JSON -> response with content of the Research Object.
    """
    if isinstance(body_specification_json, str):
        if os.path.isfile(body_specification_json):
            file = open(body_specification_json)
            body_specification_json = file.read()
    elif isinstance(body_specification_json, (dict, list)):
        body_specification_json = json.dumps(body_specification_json)
    else:
        print(f"Unexpected type of body_specification_json parameter. {type(body_specification_json)} was passed and"
              f" string (path to file) or dictionary was expected!. Leaving body_specification_json value empty.")
        body_specification_json = None
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/geolocation/"
        data = {"ro": identifier,
                "body_specification_json": body_specification_json}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_add_folders(identifier, name, description=None, parent_folder=None):
    """
    Function that adds folders to the existing Research Object.
    :param identifier: str -> Research Object's id.
    :param name: str -> name of the folder.
    :param description: str -> description.
    :param parent_folder: str -> name of the parent folder.
    :return: JSON -> response with content of the Research Object.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/folders/"
        data = {"ro": identifier,
                "name": name,
                "description": description,
                "parent_folder": parent_folder}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_add_annotations(identifier, resources=None, body_specification_json=None):
    """
    Function that adds annotations to the existing Research Object.
    :param identifier: str -> Research Object's id.
    :param resources list -> list of Research Object's resources.
    :param body_specification_json: path to JSON file or Python serializable object that
    will be converted into JSON.
    :return: JSON -> response with content of the Research Object.
    """
    if isinstance(body_specification_json, str):
        print("mam string")
        if os.path.isfile(body_specification_json):
            print("mam plik")
            file = open(body_specification_json)
            body_specification_json = file.read()
    elif isinstance(body_specification_json, (dict, list)):
        print("mam liste/slownik")
        body_specification_json = json.dumps(body_specification_json)
    else:
        print(f"Unexpected type of body_specification_json parameter. {type(body_specification_json)} was passed and"
              f" string (path to file) or dictionary was expected!. Leaving body_specification_json value empty.")
        body_specification_json = None
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/annotations/"
        print(body_specification_json)
        data = {"ro": identifier,
                "resources": resources,
                "body_specification_json": body_specification_json}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_add_internal_resource(identifier, res_type, file_path, title=None, folder=None, description=None):
    """
    Function that adds internal resource to the existing Research Object.
    :param identifier: str -> Research Object's id.
    :param res_type: str -> resource type.
    :param file_path: str -> path to the resource file.
    :param title: str -> title.
    :param folder: str -> folder id.
    :param description: str -> description.
    :return: JSON -> response with content of the Resource.
    """
    r = utils.get_request(url=settings.API_URL + "enums/")
    if r:
        available_enums = r.json()
        try:
            available_res_types = available_enums["resource_type"]
            if res_type not in available_res_types:
                msg = f"Incorrect resource type. Must be one of: {available_res_types}"
                raise SystemExit(msg)
        except KeyError as e:
            msg = f"Couldn't validate resource_type value!"
            raise SystemExit(msg)
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/resources/"
        data = {"ro": identifier,
                "folder": folder,
                "type": res_type,
                "title": title,
                "description": description}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request_with_data_and_file(url=url, data=data, file=file_path)
        content = r.json()
        return {"identifier": content.get("identifier"),
                "title": content.get("title"),
                "folder": content.get("folder"),
                "ros": content.get("ros"),
                "description": content.get("description"),
                "url": content.get("url"),
                "name": content.get("name"),
                "filename": content.get("filename"),
                "path": content.get("path"),
                "size": content.get("size"),
                "download_url": content.get("download_url"),
                "type": content.get("type"),
                "doi": content.get("doi"),
                "read_only": content.get("read_only"),
                "cloned": content.get("cloned"),
                "api_link": content.get("api_link")}
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_add_external_resource(identifier, res_type, input_url, title=None, folder=None, description=None):
    """
    Function that adds external resource to the existing Research Object.
    :param identifier: str -> Research Object's id.
    :param res_type: str -> resource type.
    :param input_url: str -> url to the resource.
    :param title: str -> title.
    :param folder: str -> folder id.
    :param description: str -> description.
    :return: JSON -> response with content of the Resource.
    """
    r = utils.get_request(url=settings.API_URL + "enums/")
    if r:
        available_enums = r.json()
        try:
            available_res_types = available_enums["resource_type"]
            if res_type not in available_res_types:
                msg = f"Incorrect resource type. Must be one of: {available_res_types}"
                raise SystemExit(msg)
        except KeyError as e:
            msg = f"Couldn't validate resource_type value!"
            raise SystemExit(msg)
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/resources/"
        data = {"ro": identifier,
                "folder": folder,
                "type": res_type,
                "title": title,
                "url": input_url,
                "description": description}
        data = {key: value for key, value in data.items() if value is not None}
        r = utils.post_request(url=url, data=data)
        content = r.json()
        return {"identifier": content.get("identifier"),
                "title": content.get("title"),
                "folder": content.get("folder"),
                "ros": content.get("ros"),
                "description": content.get("description"),
                "url": content.get("url"),
                "name": content.get("name"),
                "filename": content.get("filename"),
                "path": content.get("path"),
                "size": content.get("size"),
                "download_url": content.get("download_url"),
                "type": content.get("type"),
                "doi": content.get("doi"),
                "read_only": content.get("read_only"),
                "cloned": content.get("cloned"),
                "api_link": content.get("api_link")}
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)

###############################################################################
#              ROS upload methods.                                            #
###############################################################################


def ros_upload(path_to_zip):
    """
    Function that enables uploading zip archive in order to create a new ResearchObject.
    :param path_to_zip: str -> path to the zip package that will be uploaded.
    :return: JSON -> response from the upload endpoint.
    """
    if os.path.isfile(path_to_zip):
        if zipfile.is_zipfile(path_to_zip):
            if utils.is_valid(token_type="access"):
                url = settings.API_URL + f"ros/upload/"
                r = utils.post_request_with_file(url=url, file=path_to_zip)
                content = r.json()
                job_id = content['identifier']
                if job_id:
                    return is_job_success(job_id=job_id)
                else:
                    msg = "Incorrect job response, couldn't validate if file was uploaded or not."
                    raise SystemExit(msg)
            else:
                msg = "Your current access token is either missing or expired, please log into" \
                      " rohub again"
                raise SystemExit(msg)
        else:
            print("The file that was provided is not a real zip file! "
                  "Pleas try again with proper zip file.")
    else:
        print("Zip file doesn't exist! Please make sure passed path is correct!")


def ros_upload_resources(identifier, path_to_zip):
    """
    Function that enables uploading zip archive in order to create a new resource fo the ResearchObject.
    :param identifier: str -> Research Object's id.
    :param path_to_zip: str -> path to the zip package that will be uploaded.
    :return: JSON -> response from the upload endpoint.
    """
    if os.path.isfile(path_to_zip):
        if zipfile.is_zipfile(path_to_zip):
            if utils.is_valid(token_type="access"):
                url = settings.API_URL + f"ros/{identifier}/resources/upload/"
                r = utils.post_request_with_file(url=url, file=path_to_zip)
                content = r.json()
                job_id = content['identifier']
                if job_id:
                    return is_job_success(job_id=job_id)
                else:
                    msg = "Incorrect job response, couldn't validate if file was uploaded or not."
                    raise SystemExit(msg)
            else:
                msg = "Your current access token is either missing or expired, please log into" \
                      " rohub again"
                raise SystemExit(msg)
        else:
            print("The file that was provided is not a real zip file! "
                  "Pleas try again with proper zip file.")
    else:
        print("Zip file doesn't exist! Please make sure passed path is correct!")

###############################################################################
#              ROS delete methods.                                            #
###############################################################################


def ros_delete(identifier):
    """
    Function that deletes a Research Object with given id.
    :param identifier: str -> Research Object's id.
    :return: JSON -> response from the delete endpoint.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/"
        r = utils.delete_request(url=url)
        content = r.json()
        job_id = content['identifier']
        if job_id:
            return is_job_success(job_id=job_id)
        else:
            msg = "Incorrect job response, couldn't validate if file was uploaded or not."
            raise SystemExit(msg)
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_delete_folder(folder_identifier):
    """
    Function that deletes a folder within given Research Object.
    :param folder_identifier: str -> folder identifier.
    :return: JSON -> response from the delete endpoint.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"folders/{folder_identifier}/"
        r = utils.delete_request(url=url)
        if r.status_code != 204:
            content = r.json()
            return content
        else:
            print("Resource successfully deleted!")
            return
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_delete_resource(resource_identifier):
    """
    Function that deletes a resource within given Research Object.
    :param resource_identifier: str -> resource identifier.
    :return: JSON -> response from the delete endpoint.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"resources/{resource_identifier}/"
        r = utils.delete_request(url=url)
        if r.status_code != 204:
            content = r.json()
            return content
        else:
            print("Resource successfully deleted!")
            return
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


def ros_delete_annotation(annotation_identifier):
    """
    Function that deletes an annotation within given Research Object.
    :param annotation_identifier: str -> resource identifier.
    :return: JSON -> response from the delete endpoint.
    """
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"annotations/{annotation_identifier}/"
        r = utils.delete_request(url=url)
        if r.status_code != 204:
            content = r.json()
            return content
        else:
            print("Resource successfully deleted!")
            return
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)


###############################################################################
#              ROS put methods.                                               #
###############################################################################

def ros_update(identifier, title, research_areas, description=None, access_mode=None,
               ros_type=None, template=None, owner=None, editors=None,
               readers=None, creation_mode=None):
    """
    Function for updating Research Object.
    :param identifier: str -> Research Object's identifier.
    :param title: str -> title for the Research Object.
    :param research_areas: list -> list of research areas connected to the ResearchObject.
    :param description: str -> ResearchObject's description.
    :param access_mode: str -> ResearchObject's access mode.
    :param ros_type: str -> ResearchObject's type.
    :param template: str -> ResearchObject's template.
    :param owner: str -> ResearchObject's owner.
    :param editors: list -> ResearchObject's list of editors.
    :param readers: list -> ResearchObject's list of readers.
    :param creation_mode: str -> ResearchObject's creation mode.
    :return: JSON -> response from the put endpoint.
    """
    data = {"title": title,
            "research_areas": research_areas,
            "description": description,
            "access_mode": access_mode,
            "type": ros_type,
            "template": template,
            "owner": owner,
            "editors": editors,
            "readers": readers,
            "creation_mode": creation_mode}
    data = {key: value for key, value in data.items() if value is not None}
    if utils.is_valid(token_type="access"):
        url = settings.API_URL + f"ros/{identifier}/"
        r = utils.put_request(url=url, data=data, use_token=True)
        content = r.json()
        return content
    else:
        msg = "Your current access token is either missing or expired, please log into" \
              " rohub again"
        raise SystemExit(msg)
