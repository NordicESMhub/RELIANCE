# API SETTINGS

API_URL = "https://rohub2020-rohub.apps.paas-dev.psnc.pl/api/"

# KEYCLOAK SETTING

KEYCLOAK_CLIENT_ID = "rohub2020-frontend-devel"
KEYCLOAK_CLIENT_SECRET = "194613be-6279-43ac-9b7b-b9959f28da27"
KEYCLOAK_URL = "https://sso.apps.paas-dev.psnc.pl/auth/realms/rohub/protocol/openid-connect/token"

# USER SETTINGS

USERNAME = None
PASSWORD = None
GRANT_TYPE = "password"

# TOKEN SETTINGS

ACCESS_TOKEN = None
ACCESS_TOKEN_VALID_TO = None
REFRESH_TOKEN = None
REFRESH_TOKEN_VALID_TO = None
TOKEN_TYPE = None
SESSION_STATE = None

# REQUESTS SETTINGS

TIMEOUT = 100
RETRIES = 30
SLEEP_TIME = 2
